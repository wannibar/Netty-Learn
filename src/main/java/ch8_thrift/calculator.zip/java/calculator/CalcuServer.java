package calculator;

import gen.Calculator;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TThreadedSelectorServer;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TNonblockingServerSocket;
import org.apache.thrift.transport.TNonblockingServerTransport;
import org.apache.thrift.transport.TTransportException;

import java.net.InetSocketAddress;

/**
 * Created by WQS on 2017/7/27.
 * Mail: 1027738387@qq.com
 * Github: https://github.com/wannibar
 */
public class CalcuServer {

    public static void main(String[] args) throws TTransportException {

        CalcuHandler handler = new CalcuHandler();
        Calculator.Processor processor = new Calculator.Processor(handler);

        Runnable simple = () -> {
            simple(processor);
        };

        new Thread(simple).start();
    }


    private static void simple(Calculator.Processor processor) {
        try {

            TNonblockingServerTransport serverTransport = new TNonblockingServerSocket(
                    new InetSocketAddress("127.0.0.1", 8888));

            // TThreadedSelectorServer:与THsHaServer的主要区别在于，TThreadedSelectorServer允许你用多个线程来处理网络I/O
            // 它维护了两个线程池，一个用来处理网络I/O，另一个用来进行请求的处理
            // 当网络I/O是瓶颈的时候，TThreadedSelectorServer比THsHaServer的表现要好，大多数情况下也是如此
            // 选择TThreadedSelectorServer不会错^_^
            TFramedTransport.Factory transportF = new TFramedTransport.Factory();
            TCompactProtocol.Factory protocolF = new TCompactProtocol.Factory();
            TThreadedSelectorServer.Args args = new TThreadedSelectorServer.Args(serverTransport);
            args.processor(processor)
                    .transportFactory(transportF)
                    .protocolFactory(protocolF);
					
            TServer server = new TThreadedSelectorServer(args);
            System.out.println("Starting the  server");
            server.serve();

        } catch (TTransportException e) {
            e.printStackTrace();
        }

    }
}
