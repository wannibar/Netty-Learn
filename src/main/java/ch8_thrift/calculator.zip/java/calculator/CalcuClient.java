package calculator;

import gen.*;
import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.*;

import java.io.IOException;

/**
 * Created by WQS on 2017/7/27.
 * Mail: 1027738387@qq.com
 * Github: https://github.com/wannibar
 */
public class CalcuClient {

    public static void main(String[] args) {

        try {
            TTransport tTransport = new TFramedTransport(new TSocket("127.0.0.1", 8888));
            TCompactProtocol protocol = new TCompactProtocol(tTransport);
            tTransport.open();

            Calculator.Client client = new Calculator.Client(protocol);
            perform(client);

        } catch (TTransportException e) {
            e.printStackTrace();
        }

    }

    private static void perform(Calculator.Client client) {
        try {
            client.ping();
            System.out.println("client call ping()");

            int sum = client.add(1, 2);
            System.out.println("1+2=" + sum);

            Work work = new Work(1, 0, Operation.DIVIDE);
            try {
                int quotient = client.calculate(1000, work);
            } catch (InvalidOperation e) {
                System.out.println("invalid op :" + e.why);
            }

            work.op = Operation.SUBTRACT;
            work.num1 = 15;
            work.num2 = 10;
            try {
                int diff = client.calculate(1, work);
                System.out.println("15-10=" + diff);
            } catch (InvalidOperation io) {
                System.out.println("Invalid operation: " + io.why);
            }

            SharedStruct log = client.getStruct(1);
            System.out.println(log);
            System.out.println("check log:" + log.value);

        } catch (TException e) {
            e.printStackTrace();
        }
    }
}
